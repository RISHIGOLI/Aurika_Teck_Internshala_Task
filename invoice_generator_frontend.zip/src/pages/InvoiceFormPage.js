import React from 'react'
import {makeStyles,Grid, Button} from '@material-ui/core'
import InvoiceForm from '../components/InvoiceForm'

export default function InvoiceFormPage(){

    
    return (
        <Grid style={{display: 'flex', flexDirection: 'column'}}>
            <h3>Invoice Generator</h3>
            
            <InvoiceForm/>
        </Grid>
    )
}