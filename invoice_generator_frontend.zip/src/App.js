import logo from './logo.svg';
import './App.css';
import InvoiceFormPage from './pages/InvoiceFormPage';
import ShowPdf from './components/ShowPdf';

function App() {
  const data = {
    "sellerDetails": {
        "name": "Rakesh Goli",
        "address": "123 MIDC Sunil Nagar Solapur",
        "city": "Solapur",
        "state": "Maharashtra",
        "pincode": "413006",
        "panNo": "ASDFG1234T",
        "gstNo": "ASD213512POIUQASEF"
    },
    "placeOfSupply": "Solapur",
    "billingDetails": {
        "name": "Rushikesh Ambaji Goli",
        "address": "875 Ashok Chowk Solapur",
        "city": "Solapur ",
        "state": "Maharashtra",
        "pincode": "413005",
        "stateCode": "MH"
    },
    "shippingDetails": {
        "name": "Rushikesh Ambaji Goli",
        "address": "875 Ashok Chowk Solapur",
        "city": "Solapur",
        "state": "Maharashtra",
        "pincode": "413005",
        "stateCode": "MH"
    },
    "placeOfDelivery": "Solapur",
    "orderDetails": {
        "orderNo": "123456789",
        "orderDate": "2024-06-03T00:00:00.000Z"
    },
    "invoiceDetails": {
        "invoiceNo": "ASDF1234",
        "invoiceDate": "2024-06-02T00:00:00.000Z"
    },
    "reverseCharge": false,
    "items": [
        {
            "description": "Mens T Shirt",
            "unitPrice": 199,
            "quantity": 3,
            "discount": 12,
            "taxRate": 18,
            "netAmount": 525.36,
            "cgstAmount": 47.282399999999996,
            "sgstAmount": 47.282399999999996,
            "totalAmount": 619.9248,
            "_id": "665c6dd5f022bcd808236707"
        },
        {
            "description": "Mens Shirts Formal XL supreme",
            "unitPrice": 499,
            "quantity": 2,
            "discount": 15,
            "taxRate": 18,
            "netAmount": 848.3,
            "cgstAmount": 76.347,
            "sgstAmount": 76.347,
            "totalAmount": 1000.9939999999999,
            "_id": "665c6dd5f022bcd808236708"
        }
    ],
    "amountInWords": "one thousand, six hundred twenty",
    "signature": "Rakesh Goli",
    "_id": "665c6dd5f022bcd808236706",
    "__v": 0
}
  return (
    <div className="App">
      <InvoiceFormPage/>
    </div>
  );
}

export default App;
