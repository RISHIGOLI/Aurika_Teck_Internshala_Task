import React from "react"
import { Document, Page, View, Text, StyleSheet } from '@react-pdf/renderer'
import { useState } from "react";

const styles = StyleSheet.create({
    page: {
        display: 'flex',
        flexDirection: 'column',
        padding: 20,
    },
    section: {
        display: 'flex',
        flexDirection: 'column',
        margin: 10,
        padding: 10,
        flexGrow: 1,
        // border: '1px solid black'
    },
    header: {
        display: 'flex',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    title: {
        fontSize: 24,
        marginBottom: 10,
        fontWeight: 'bold',
    },
    subtitle: {
        fontSize: 18,
        marginBottom: 10,
        fontWeight: 'bold',
    },
    highText: {
        fontSize: 18,
        marginBottom: 5,
    },
    mediumText: {
        fontSize: 10
    },
    smallText: {
        fontSize: 8
    },
    table: {
        display: "table",
        width: "auto",
        borderStyle: "solid",
        borderWidth: 1,
        borderRightWidth: 0,
        borderBottomWidth: 0
    },
    tableRow: {
        margin: "auto",
        flexDirection: "row",
        width: '100%'
    },
    tableCell: {
        margin: "auto",
        marginTop: 5,
        fontSize: 12,
        borderStyle: "solid",
        borderWidth: 1,
        borderLeftWidth: 0,
        borderTopWidth: 0
    }
})

export default function ShowPdf({ data }) {

    const [grandTotalAmount, setGrandTotalAmount] = useState(0)
    const [totalTaxAmount, setTotalTaxAmount] = useState(0)
    const [totalNetAmount, setTotalNetAmount] = useState(0)

    // Calculate grand total when data?.items changes
    React.useEffect(() => {
        if (data && data.items) {
            const total = data?.items.reduce((acc, item) => acc + item.totalAmount, 0);
            setGrandTotalAmount(total);
        }

        if (data && data.items) {
            const total = data?.items.reduce((acc, item) => {
                // Check if igst is true, if true, add igstAmount, otherwise, add cgstAmount + sgstAmount
                const taxAmount = item.igstAmount ? item.igstAmount : item.cgstAmount + item.sgstAmount;
                return acc + taxAmount;
            }, 0);

            setTotalTaxAmount(total);
        }
    }, [data]);

    const formatDate = (isoString) => {
        const date = new Date(isoString);

        // Extract year, month, and day
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
        const day = String(date.getDate()).padStart(2, '0');

        // Format the date as YYYY-MM-DD
        return `${day}-${month}-${year}`;
    };

    return (
        <Document>
            <Page size='A4'>
                <View style={styles.section}>
                    <View style={styles.header}>
                        <View>
                            <Text style={{ fontSize: '50px', fontWeight: 'bold', color: 'blue' }}>Aurika Tech</Text>
                        </View>
                        <View>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.title }}>Tax Invoice / Bill of Supply / Cash Memo</Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>(Original for Recipient)</Text>
                        </View>
                    </View>

                    {/* sold by and billing address */}
                    <View style={{ display: 'flex', justifyContent: 'space-between' }}>
                        {/* sold by */}
                        <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start' }}>
                            <Text style={{ display: 'flex', justifyContent: 'flex-start', ...styles.subtitle }}>Sold By : </Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-start', ...styles.highText }}>{data?.sellerDetails?.name}</Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-start', ...styles.highText }}>{data?.sellerDetails?.address}</Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-start', ...styles.highText }}>{data?.sellerDetails?.city}, {data?.sellerDetails?.state} - {data?.sellerDetails?.pincode}</Text>
                        </View>

                        {/* billing address */}
                        <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.subtitle }}>Billing Address :  </Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>{data?.billingDetails?.name}</Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>{data?.billingDetails?.address}</Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>{data?.billingDetails?.city}, {data?.billingDetails?.state} - {data?.billingDetails?.pincode}</Text>
                        </View>
                    </View>

                    {/* pan gst and state code */}
                    <View style={{ display: 'flex', flexDirection: 'column' }}>
                        {/* pan and state code */}
                        <View style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <View>
                                <Text style={styles.subtitle}>PAN No. : </Text>
                                <Text style={styles.highText}>{data?.sellerDetails.panNo}</Text>
                            </View>

                            <View>
                                <Text style={styles.subtitle}>State/UT Code : </Text>
                                <Text style={styles.highText}>{data?.billingDetails?.stateCode}</Text>
                            </View>
                        </View>

                        {/* gst */}
                        <View style={{ display: 'flex' }}>
                            <Text style={styles.subtitle}>GST Registration No. : </Text>
                            <Text style={styles.highText}>{data?.sellerDetails.gstNo}</Text>
                        </View>

                    </View>

                    {/* shipping addres */}
                    <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                        <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.subtitle }}>Shipping Address :  </Text>
                        <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>{data?.shippingDetails.name}</Text>
                        <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>{data?.shippingDetails.address}</Text>
                        <Text style={{ display: 'flex', justifyContent: 'flex-end', ...styles.highText }}>{data?.shippingDetails.city}, {data?.shippingDetails.state} - {data?.shippingDetails.pincode}</Text>
                    </View>

                    {/* state or ut code */}
                    <View style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Text style={styles.subtitle}>State/UT Code : </Text>
                        <Text style={styles.highText}>{data?.shippingDetails.stateCode}</Text>
                    </View>

                    {/* place of supply */}
                    <View style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Text style={styles.subtitle}>Place of supply : </Text>
                        <Text style={styles.highText}>{data?.placeOfSupply}</Text>
                    </View>

                    {/* place of delivery */}
                    <View style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Text style={styles.subtitle}>Place of delivery : </Text>
                        <Text style={styles.highText}>{data?.placeOfDelivery}</Text>
                    </View>

                    <View style={{ display: 'flex', flexDirection: 'column' }}>
                        <View style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <View style={{ display: 'flex' }}>
                                <Text style={styles.subtitle}>Order No. : </Text>
                                <Text style={styles.highText}>{data?.orderDetails.orderNo}</Text>
                            </View>
                            <View style={{ display: 'flex' }}>
                                <Text style={styles.subtitle}>Invoice No. : </Text>
                                <Text style={styles.highText}>{data?.invoiceDetails.invoiceNo}</Text>
                            </View>
                        </View>

                        <View style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <View style={{ display: 'flex' }}>
                                <Text style={styles.subtitle}>Order Date : </Text>
                                <Text style={styles.highText}>{formatDate(data?.orderDetails.orderDate)}</Text>
                            </View>
                            <View style={{ display: 'flex' }}>
                                <Text style={styles.subtitle}>Invoice Details : </Text>
                                <Text style={styles.highText}>ASAFA2323F</Text>
                            </View>
                        </View>
                        <View style={{ display: 'flex', justifyContent: 'flex-end' }}>
                            <Text style={styles.subtitle}>Invoice Date : </Text>
                            <Text style={styles.highText}>{formatDate(data?.invoiceDetails.invoiceDate)}</Text>
                        </View>
                    </View>

                    {/* tables */}
                    <View style={{ display: 'flex', width: '100%', border: '1px solid black', flexDirection: 'column' }}>
                        {/* title row */}
                        <View style={{ width: '100%', display: 'flex', justifyContent: 'flex-start', backgroundColor: 'whitesmoke' }}>
                            <Text style={{ paddingLeft: '5px', fontWeight: 'bold', width: '5%', border: '1px solid black' }}>Sr No</Text>
                            <Text style={{ fontWeight: 'bold', width: '40%', border: '1px solid black' }}>Description</Text>
                            <Text style={{ fontWeight: 'bold', width: '10%', border: '1px solid black' }}>Unit Price</Text>
                            <Text style={{ fontWeight: 'bold', width: '5%', border: '1px solid black' }}>Qty</Text>
                            <Text style={{ fontWeight: 'bold', width: '10%', border: '1px solid black' }}>Net Amount</Text>
                            <Text style={{ fontWeight: 'bold', width: '5%', border: '1px solid black' }}>Tax Rate</Text>
                            <Text style={{ fontWeight: 'bold', width: '5%', border: '1px solid black' }}>Tax Type</Text>
                            <Text style={{ fontWeight: 'bold', width: '10%', border: '1px solid black' }}>Tax Amount</Text>
                            <Text style={{ paddingRight: '5px', fontWeight: 'bold', width: '10%', border: '1px solid black' }}>Total Amount</Text>
                        </View>

                        {/* items row */}
                        {/* will be done at last */}
                        {
                            data?.items?.map((item, index) => (
                                <React.Fragment key={item.id}>
                                    <View style={{ width: '100%', display: 'flex', justifyContent: 'flex-start' }} >
                                        <Text style={{ paddingLeft: '5px', width: '5%', border: '1px solid black' }}>{index + 1}</Text>
                                        <Text style={{ width: '40%', border: '1px solid black' }}>{item.description}</Text>
                                        <Text style={{ width: '10%', border: '1px solid black' }}>{item.unitPrice}</Text>
                                        <Text style={{ width: '5%', border: '1px solid black' }}>{item.quantity}</Text>
                                        <Text style={{ width: '10%', border: '1px solid black' }}>{item.netAmount.toFixed(2)}</Text>
                                        <Text style={{ width: '5%', border: '1px solid black' }}>{item.igstAmount ? 18 : 9}</Text>
                                        <Text style={{ width: '5%', border: '1px solid black' }}>{item.igstAmount ? 'IGST' : 'CGST'}</Text>
                                        <Text style={{ width: '10%', border: '1px solid black' }}>{item.igstAmount ? item.taxAmount.toFixed(2) : item.cgstAmount.toFixed(2)}</Text>
                                        <Text style={{ paddingRight: '5px', width: '10%', border: '1px solid black' }}>{item.totalAmount.toFixed(2)}</Text>
                                    </View>

                                    <View style={{ width: '100%', display: 'flex', justifyContent: 'flex-start' }} >
                                        <Text style={{ paddingLeft: '5px', width: '5%', border: '1px solid black' }}></Text>
                                        <Text style={{ width: '40%', border: '1px solid black' }}></Text>
                                        <Text style={{ width: '10%', border: '1px solid black' }}></Text>
                                        <Text style={{ width: '5%', border: '1px solid black' }}></Text>
                                        <Text style={{ width: '10%', border: '1px solid black' }}></Text>
                                        <Text style={{ width: '5%', border: '1px solid black' }}>{item.taxRate / 2}</Text>
                                        <Text style={{ width: '5%', border: '1px solid black' }}>{'SGST'}</Text>
                                        <Text style={{ width: '10%', border: '1px solid black' }}>{item.sgstAmount.toFixed(2)}</Text>
                                        <Text style={{ paddingRight: '5px', width: '10%', border: '1px solid black' }}></Text>
                                    </View>
                                </React.Fragment>
                            ))
                        }

                        {/* total row */}
                        <View style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid black' }}>
                            <View style={{ fontWeight: 'bold' }}>TOTAL : </View>
                            <View style={{ width: '20%', backgroundColor: 'whitesmoke', display: 'flex' }}>
                                <Text style={{ width: '50%', border: '1px solid black' }}>{totalTaxAmount.toFixed(2)}</Text>
                                <Text style={{ width: '50%', border: '1px solid black', paddingRight: '8px' }}>{grandTotalAmount.toFixed(2)}</Text>
                            </View>
                        </View>

                        {/* amount in words */}
                        <View style={{ width: '100%', fontWeight: 'bold', display: 'flex', flexDirection: 'column', borderBottom: '1px solid black' }}>
                            <Text style={{ display: 'flex', justifyContent: 'flex-start' }}>Amount in words : </Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-start' }}>{data?.amountInWords} rupees only.</Text>
                        </View>

                        {/* signauture section */}
                        <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', fontWeight: 'bold' }}>For varasiddhi exports : </Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', fontWeight: 'bold', border: '1px solid black', width: 'max-content' }}>{data?.signature}</Text>
                            <Text style={{ display: 'flex', justifyContent: 'flex-end', fontWeight: 'bold' }}>Authorized signatory </Text>
                        </View>
                    </View>
                    <Text style={{ display: 'flex', justifyContent: 'flex-start' }}>Whether the tax is payable under reverse charge - {data?.reverseCharge ? 'Yes' : 'No'}</Text>
                </View>
            </Page>
        </Document>
    )
}