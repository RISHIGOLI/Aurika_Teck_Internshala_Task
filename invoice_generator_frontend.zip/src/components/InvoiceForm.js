import React, { useState } from 'react';
import axios from 'axios';
import { makeStyles } from '@material-ui/core/styles';
import {
    TextField, Button, Typography, Grid, Container, Paper,
    Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton
} from '@material-ui/core';
import DeleteIcon from '@material-ui/icons/Delete';
import ShowPdf from './ShowPdf';

const useStyles = makeStyles((theme) => ({
    form: {
        marginTop: theme.spacing(3),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
    table: {
        marginTop: theme.spacing(3),
    },
}));

const InvoiceForm = () => {
    const [invoicePdfData, setInvoicePdfData] = useState()
    const classes = useStyles();
    const [invoiceData, setInvoiceData] = useState({
        sellerDetails: {
            name: '',
            address: '',
            city: '',
            state: '',
            pincode: '',
            panNo: '',
            gstNo: ''
        },
        placeOfSupply: '',
        billingDetails: {
            name: '',
            address: '',
            city: '',
            state: '',
            pincode: '',
            stateCode: ''
        },
        shippingDetails: {
            name: '',
            address: '',
            city: '',
            state: '',
            pincode: '',
            stateCode: ''
        },
        placeOfDelivery: '',
        orderDetails: {
            orderNo: '',
            orderDate: ''
        },
        invoiceDetails: {
            invoiceNo: '',
            invoiceDate: '',
            invoiceDueDate: ''
        },
        reverseCharge: false,
        items: [],
        signature: ''
    });

    const [item, setItem] = useState({
        description: '',
        unitPrice: 0,
        quantity: 0,
        discount: 0,
        taxRate: 0
    });

    const [pdfUrl, setPdfUrl] = useState(null);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        const [field, subField] = name.split('.');
        if (subField) {
            setInvoiceData({
                ...invoiceData,
                [field]: {
                    ...invoiceData[field],
                    [subField]: value
                }
            });
        } else {
            setInvoiceData({
                ...invoiceData,
                [name]: value
            });
        }
    };

    const handleItemChange = (e) => {
        const { name, value } = e.target;
        setItem({
            ...item,
            [name]: value
        });
    };

    const addItem = () => {
        setInvoiceData({
            ...invoiceData,
            items: [...invoiceData.items, item]
        });
        setItem({
            description: '',
            unitPrice: 0,
            quantity: 0,
            discount: 0,
            taxRate: 0
        });
    };

    const removeItem = (index) => {
        const updatedItems = invoiceData.items.filter((_, i) => i !== index);
        setInvoiceData({
            ...invoiceData,
            items: updatedItems
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(invoiceData)
        // Basic validation
        if (!invoiceData.sellerDetails.name || !invoiceData.billingDetails.name || !invoiceData.shippingDetails.name) {
            alert('Please fill out all required fields.');
            return;
        }

        try {
            const response = await axios.post('http://localhost:3000/api/invoices', invoiceData);
            // const url = window.URL.createObjectURL(new Blob([response.data]));
            // setPdfUrl(url);
            console.log('api response = ', response.data)
            setInvoicePdfData(response.data)
        } catch (error) {
            console.error('Error generating invoice:', error);
        }
    };

    
    const downloadPdf = async () => {
        try {
            // Call generateInvoice to ensure invoicePdfData is populated
            // await generateInvoice(invoiceData);

            // Convert PDF content to Blob
            const blob = new Blob([invoicePdfData], { type: 'application/pdf' });

            // Create URL for Blob
            const url = URL.createObjectURL(blob);

            // Initiate download
            const link = document.createElement('a');
            link.href = url;
            link.download = 'invoice.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error('Error downloading PDF:', error);
        }
        try {
            // Call generateInvoice to ensure invoicePdfData is populated
            // await generateInvoice(invoiceData);
    
            console.log('invoicePdfData:', invoicePdfData); // Log the content of invoicePdfData
    
            // Convert PDF content to Blob
            const pdfContent = <ShowPdf data={invoicePdfData} />; // Get the PDF content
            const blob = new Blob([pdfContent], { type: 'application/pdf' });
    
            console.log('blob:', blob); // Log the created Blob
    
            // Create URL for Blob
            const url = URL.createObjectURL(blob);
    
            console.log('url:', url); // Log the created URL
    
            // Initiate download
            window.open(url);
        } catch (error) {
            console.error('Error downloading PDF:', error);
        }
    };
    
    


    return (
        <Container component="main" maxWidth="md">
            <Typography component="h1" variant="h5">
                Generate Invoice
            </Typography>
            <Button onClick={()=>downloadPdf()}>Download PDF</Button>
            {
                !invoicePdfData ?
                    <form className={classes.form} onSubmit={handleSubmit}>
                        <Typography variant="h6">Seller Details</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <TextField name="sellerDetails.name" label="Name" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="sellerDetails.address" label="Address" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="sellerDetails.city" label="City" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="sellerDetails.state" label="State" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="sellerDetails.pincode" label="Pincode" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="sellerDetails.panNo" label="PAN No" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="sellerDetails.gstNo" label="GST No" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Billing Details</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <TextField name="billingDetails.name" label="Name" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="billingDetails.address" label="Address" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="billingDetails.city" label="City" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="billingDetails.state" label="State" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="billingDetails.pincode" label="Pincode" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="billingDetails.stateCode" label="State Code" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Shipping Details</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <TextField name="shippingDetails.name" label="Name" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="shippingDetails.address" label="Address" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="shippingDetails.city" label="City" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="shippingDetails.state" label="State" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="shippingDetails.pincode" label="Pincode" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="shippingDetails.stateCode" label="State Code" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Place of Supply</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField name="placeOfSupply" label="Place of Supply" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Place of Delivery</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField name="placeOfDelivery" label="Place of Delivery" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Order Details</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <TextField name="orderDetails.orderNo" label="Order No" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField name="orderDetails.orderDate" label="Order Date" type="date" onChange={handleInputChange} variant="outlined" fullWidth InputLabelProps={{ shrink: true }} />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Invoice Details</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={4}>
                                <TextField name="invoiceDetails.invoiceNo" label="Invoice No" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="invoiceDetails.invoiceDate" label="Invoice Date" type="date" onChange={handleInputChange} variant="outlined" fullWidth InputLabelProps={{ shrink: true }} />
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <TextField name="invoiceDetails.invoiceDueDate" label="Invoice Due Date" type="date" onChange={handleInputChange} variant="outlined" fullWidth InputLabelProps={{ shrink: true }} />
                            </Grid>
                        </Grid>

                        <Typography variant="h6">Items</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={4}>
                                <TextField name="description" label="Description" value={item.description} onChange={handleItemChange} variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={2}>
                                <TextField name="unitPrice" label="Unit Price" value={item.unitPrice} onChange={handleItemChange} type="number" variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={2}>
                                <TextField name="quantity" label="Quantity" value={item.quantity} onChange={handleItemChange} type="number" variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={2}>
                                <TextField name="discount" label="Discount (%)" value={item.discount} onChange={handleItemChange} type="number" variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12} sm={2}>
                                <TextField name="taxRate" label="Tax Rate (%)" value={item.taxRate} onChange={handleItemChange} type="number" variant="outlined" fullWidth />
                            </Grid>
                            <Grid item xs={12}>
                                <Button variant="contained" color="primary" onClick={addItem}>
                                    Add Item
                                </Button>
                            </Grid>
                        </Grid>

                        {invoiceData.items.length > 0 && (
                            <TableContainer component={Paper} className={classes.table}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Description</TableCell>
                                            <TableCell>Unit Price</TableCell>
                                            <TableCell>Quantity</TableCell>
                                            <TableCell>Discount (%)</TableCell>
                                            <TableCell>Tax Rate (%)</TableCell>
                                            <TableCell>Actions</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {invoiceData.items.map((item, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{item.description}</TableCell>
                                                <TableCell>{item.unitPrice}</TableCell>
                                                <TableCell>{item.quantity}</TableCell>
                                                <TableCell>{item.discount}</TableCell>
                                                <TableCell>{item.taxRate}</TableCell>
                                                <TableCell>
                                                    <IconButton onClick={() => removeItem(index)}>
                                                        <DeleteIcon />
                                                    </IconButton>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        )}

                        <Typography variant="h6">Signature</Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField name="signature" label="Signature URL" onChange={handleInputChange} variant="outlined" fullWidth />
                            </Grid>
                        </Grid>

                        <Button type="submit" variant="contained" color="primary" className={classes.submit}>
                            Generate Invoice
                        </Button>
                    </form> :
                    <ShowPdf data={invoicePdfData} />
            }

        </Container>
    );
};

export default InvoiceForm;
