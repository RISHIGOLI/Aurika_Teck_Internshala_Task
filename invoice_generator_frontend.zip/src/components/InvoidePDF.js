import React from 'react';
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    padding: 20,
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1,
  },
  header: {
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  text: {
    fontSize: 12,
    marginBottom: 5,
  },
});

const InvoicePDF = ({ data }) => {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.section}>
          <View style={styles.header}>
            <Text style={styles.title}>Invoice</Text>
            <Text style={styles.text}>Invoice No: {data.invoiceDetails.invoiceNo}</Text>
            <Text style={styles.text}>Invoice Date: {data.invoiceDetails.invoiceDate}</Text>
            <Text style={styles.text}>Due Date: {data.invoiceDetails.invoiceDueDate}</Text>
          </View>
          
          <View style={styles.section}>
            <Text style={styles.subtitle}>Seller Details</Text>
            <Text style={styles.text}>Name: {data.sellerDetails.name}</Text>
            <Text style={styles.text}>Address: {data.sellerDetails.address}</Text>
            <Text style={styles.text}>City: {data.sellerDetails.city}</Text>
            <Text style={styles.text}>State: {data.sellerDetails.state}</Text>
            <Text style={styles.text}>Pincode: {data.sellerDetails.pincode}</Text>
            <Text style={styles.text}>PAN No: {data.sellerDetails.panNo}</Text>
            <Text style={styles.text}>GST No: {data.sellerDetails.gstNo}</Text>
          </View>

          {/* Render other sections like billing details, shipping details, items, etc. */}
        </View>
      </Page>
    </Document>
  );
};

export default InvoicePDF;
