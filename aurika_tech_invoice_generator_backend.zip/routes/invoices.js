const express = require('express')
const Invoice = require('../models/invoice')
const router = express.Router()
const numberToWords = require('number-to-words');

//get all invoices
router.get('/',async (req,res)=>{
    try{
        const invoices = await Invoice.find()
        res.json(invoices)
    }catch(error){
        res.status(500).json({ message: err.message });
    }
})

router.post('/', async (req, res) => {
    const invoiceData = req.body

    // Validate input data
    if (!invoiceData || !invoiceData.items || !invoiceData.sellerDetails || !invoiceData.billingDetails || !invoiceData.shippingDetails) {
        return res.status(400).send('Invalid input data');
    }

    // Derive computed fields
    const placeOfSupply = invoiceData.placeOfSupply;
    const placeOfDelivery = invoiceData.placeOfDelivery;

    invoiceData.items.forEach(item => {
        // Handle no discount case
        const discount = item.discount ? item.discount : 0;
        const discountAmount = (item.unitPrice * item.quantity) * (discount / 100);
        item.netAmount = (item.unitPrice * item.quantity) - discountAmount;

        // Determine tax type and calculate tax amounts
        if (placeOfSupply === placeOfDelivery) {
            // CGST and SGST
            item.taxRate = 18; // Total tax rate
            const cgstRate = item.taxRate / 2; // 9%
            const sgstRate = item.taxRate / 2; // 9%
            item.cgstAmount = item.netAmount * cgstRate / 100;
            item.sgstAmount = item.netAmount * sgstRate / 100;
            item.taxType = 'CGST+SGST';
            item.taxAmount = item.cgstAmount + item.sgstAmount;
        } else {
            // IGST
            item.taxRate = 18; // IGST rate
            item.igstAmount = item.netAmount * item.taxRate / 100;
            item.taxType = 'IGST';
            item.taxAmount = item.igstAmount;
        }

        item.totalAmount = item.netAmount + item.taxAmount;
    });

    // Calculate total amount
    const totalAmount = invoiceData.items.reduce((acc, item) => acc + item.totalAmount, 0);
    invoiceData.grandTotalAmount = totalAmount
    
    // Calculate total amount in words
    invoiceData.amountInWords = numberToWords.toWords(totalAmount);

    try {
        const invoice = new Invoice(invoiceData);
        const savedInvoice = await invoice.save();
        res.json(savedInvoice);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
})

module.exports = router